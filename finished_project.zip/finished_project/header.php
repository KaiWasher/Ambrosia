<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>

   
    </head>
    <body>
        <table>
		<tr>
			<td><a href= "home.php">
	<img src = "farma.png" alt="troll face" width="200" height="120">
	</a>
	</td>
  <td><h1>Ambrosia</h1></td>
               
	</table>
       
</div>


        
        
        
        
        
    </body>
    
    
    
</html>