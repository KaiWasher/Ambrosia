<!DOCTYPE html>
<html>
 
    <head>
        <title>Ambrosia</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       

      
    </head>

        <script>
    function disc(){
        alert("We promise our users that their information will not be sold or misused, and protects the website builder from any incorrect information. ");
        
    }
    function disc2(){
        alert(" We are the best in the business ");
        
    }
        function disc3(){
        alert(" Our phone number is: 514-134-4431 ");
        
    }
            function disc4(){
        alert(" Send us your CV ");
        
    }


</script>
<style>
    #foot{background-color: #f4b342};
    
</style>
<html>
    <body>
        <br/><fieldset id="foot">
        <p><a style="display:inline-block;padding-right:20px;" href="" onclick="disc();"> Privacy/Disclaimer
    Statement </a>
            <a style="display:inline-block;padding-right:20px;" href="" onclick="disc2();"> About us </a>
            <a style="display:inline-block; padding-right:20px;" href="" onclick="disc3();"> Contact us </a>
        <a style="display:inline-block;padding-right:20px;" href="" onclick="disc4();"> Careers </a>
        </p>
        
        
       </fieldset>

        
        
        
        
        
    </body>
    
    
    
    
    
</html>
    </body>
</html>